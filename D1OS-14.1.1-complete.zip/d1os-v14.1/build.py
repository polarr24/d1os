from pathlib import Path
import json
p=Path(__file__).parent
head='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#080b0e"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'self'; style-src 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; font-src 'none'; object-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'"><title>D1OS 14 · Zayden</title><link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="icon.svg"><link rel="apple-touch-icon" href="icon-192.png"><style>'''
body='''</style></head><body><header><div class="mark">D1</div><div class="brand">D1OS<small>ZAYDEN / FIELD OPERATIONS</small></div><button class="utility" data-act="large" aria-label="Toggle large text">Aa</button><button class="utility" data-act="field" aria-label="Toggle sunlight Field Mode">☀</button></header><div class="wrap"><div class="between" style="padding:8px 18px 0"><span class="eyebrow">v14.0 / LOCAL FIRST</span><small id="saveState">CHECKING</small></div><div id="toast" role="status" aria-live="polite" class="notice"></div><main id="screen"><h1>Opening your record…</h1><noscript>Enable JavaScript to use D1OS. Athlete data stays in this browser.</noscript></main></div><nav aria-label="Main destinations">'''
for k,icon in [('today','⌂'),('field','↗'),('train','▥'),('lab','◎'),('path','≡')]:body+=f'<button data-act="go:{k}"><span aria-hidden="true">{icon}</span>{k.upper()}</button>'
body+='</nav>'
html=head+(p/'src/style.css').read_text()+body
for f in ['core.js','content.js','journey.js','app.js']:html+='<script>\n'+(p/'src'/f).read_text()+'\n</script>'
html=html.replace('v14.0 / LOCAL FIRST','v14.1.1 / LOCAL FIRST').replace('D1OS 14 · Zayden','D1OS 14.1.1 · Zayden').replace('href="icon-192.png"','href="icon-180.png"')
html+='</body></html>'
(p/'index.html').write_text(html)
(p/'manifest.webmanifest').write_text(json.dumps({'name':'D1OS · Zayden','short_name':'D1OS','start_url':'./index.html','scope':'./','display':'standalone','background_color':'#080b0e','theme_color':'#080b0e','icons':[{'src':'icon-180.png','sizes':'180x180','type':'image/png'},{'src':'icon-512.png','sizes':'512x512','type':'image/png'}]},indent=2))
(p/'manifest.json').write_text((p/'manifest.webmanifest').read_text())
(p/'icon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"><rect width="192" height="192" rx="32" fill="#080b0e"/><rect x="24" y="24" width="144" height="144" rx="18" fill="none" stroke="#ffd178" stroke-width="6"/><text x="96" y="126" text-anchor="middle" font-family="sans-serif" font-size="84" font-weight="900" fill="#ffd178">D1</text></svg>')
print('Built',len(html.encode()),'bytes')
