# Test fixtures and results

Run from this tests directory; instructions are in ../TESTLOG.md.

fixtures/v13.4-source.html is the unchanged, actual attached previous application, retained solely for migration regression tests. It can contain obsolete recommendations. Do not open it as Zayden’s current app. Open ../index.html instead.

fixtures/v14-seed.json is the actual prior v14.0 seed used to test the same-schema upgrade and preservation of original fact timestamps. The separate populated v14 migration scenario uses synthetic records; no private athlete browser history was supplied.

core-results.json, audit-results.json, ui-results.json, journey-ui-results.json and release-results.json are outputs of this build’s executed tests. Development browser binaries and package caches are deliberately excluded from the deliverable.
