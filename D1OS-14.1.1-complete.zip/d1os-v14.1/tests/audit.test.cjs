const C=require('../src/core.js'),assert=require('node:assert/strict'),fs=require('fs');
const results=[];function test(name,fn){try{fn();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.message})}}
const at=(d,t='10:00')=>new Date(C.zoned(d,t)),sun=at('2026-09-27');
function ready(d='2026-09-27'){let s=C.seed();s.facts.injury=C.fact('No reported pain',1,'reported','test',C.zoned(d,'08:00'));return C.event(s,'readiness',{sleep:9,fresh:5,energy:5,pain:'no',illness:'no',supervised:true,extraLoadReviewed:true,speedIncluded:'no'},at(d,'08:00'),'readiness-'+d)}
test('Old check-in cannot authorize work without new illness answer',()=>{let s=ready();delete s.events[0].payload.illness;assert.equal(C.plan(s,sun).allowed,false)});
test('Unreviewed extra activity holds optional lifting',()=>{let s=ready();s.events[0].payload.extraLoadReviewed=false;assert.equal(C.plan(s,sun).allowed,false)});
test('Illness overrides even game day',()=>{let s=ready('2026-10-01');s.events[0].payload.illness='yes';assert.equal(C.plan(s,at('2026-10-01')).code,'recovery')});
test('Hard outside sport suppresses lower lift and sprints',()=>{let s=C.event(ready(),'activity',{minutes:45,rpe:9,contact:'none',occurredAt:C.zoned('2026-09-26','17:00')},sun);assert.equal(C.plan(s,sun).allowed,false);assert.equal(C.plan(s,sun).sprint,false)});
test('Backfilled old activity uses occurrence time, not entry time',()=>{let s=C.event(ready(),'activity',{minutes:60,rpe:9,occurredAt:C.zoned('2026-09-23','17:00')},sun);assert.equal(C.plan(s,sun).allowed,true)});
test('Future activity does not become a completed workload',()=>{let s=C.event(ready(),'activity',{minutes:60,rpe:9,occurredAt:C.zoned('2026-09-28','17:00')},sun);assert.equal(C.loadReview(s,sun).hard.length,0)});
test('Near-failure working set holds subsequent optional work',()=>{let s=C.event(ready(),'set',{exercise:'bench',rir:'1',reps:5},at('2026-09-26','14:00'));assert.equal(C.plan(s,sun).allowed,false)});
test('Deteriorating technique holds restart even with high RIR',()=>{let s=C.event(ready(),'set',{exercise:'bench',rir:'4',technique:'deteriorated',reps:5},sun);assert.equal(C.plan(s,sun).allowed,false)});
test('Missing legacy RIR is unknown, not a zero',()=>{let s=C.event(ready(),'set',{exercise:'bench',rir:null,reps:5},sun);assert.equal(C.loadReview(s,sun).hard.length,0)});
test('Logged acceleration closes duplicate sprint dose',()=>{let s=C.event(ready(),'exposure',{kind:'max-intent acceleration',reps:4},sun);assert.equal(C.plan(s,sun).sprint,false);assert.equal(C.plan(s,sun).allowed,true)});
test('Logged high-speed exposure also holds additional acceleration',()=>{let s=C.event(ready(),'exposure',{kind:'high-speed exposure',reps:2},sun);assert.equal(C.plan(s,sun).sprint,false)});
test('Mechanics log is not misclassified as max speed',()=>{let s=C.event(ready(),'exposure',{kind:'mechanics',reps:10},sun);assert.equal(C.plan(s,sun).sprint,true)});
test('Lower lifting precedes a sprint hold, not a sprint finisher',()=>{let s=C.event(ready(),'set',{exercise:'trap',rir:4,reps:4},sun);assert.equal(C.plan(s,sun).sprint,false)});
test('Even moderate extra activity holds extra maximal sprints',()=>{let s=C.event(ready(),'activity',{minutes:30,rpe:5},sun);assert.equal(C.plan(s,sun).sprint,false);assert.equal(C.plan(s,sun).allowed,true)});
test('Six actual training days protect seventh day',()=>{let s=ready();for(let i=1;i<=6;i++)s=C.event(s,'activity',{minutes:30,rpe:4},at(C.add('2026-09-27',-i)));assert.equal(C.trainingDays(s,sun),6);assert.equal(C.plan(s,sun).allowed,false)});
test('Missed practice is not counted as training day',()=>{let s=C.event(ready(),'practice',{minutes:0,missed:true},at('2026-09-26'));assert.equal(C.trainingDays(s,sun),0)});
test('Three distinct concern days prompt review without diagnosis',()=>{let s=ready();for(let i=1;i<=3;i++)s=C.event(s,'readiness',{energy:4,appetite:'low'},at(C.add('2026-09-27',-i)));assert.equal(C.wellness(s,sun).review,true)});
test('Three entries on one day do not invent three concern days',()=>{let s=ready();for(let i=1;i<=3;i++)s=C.event(s,'readiness',{energy:2},at('2026-09-26'),String(i));assert.equal(C.wellness(s,sun).concernDays,1)});
function sets({rir='3',quality='steady',load2=145,missing=false,sameDay=false}={}){let s=ready();for(let j=0;j<2;j++){let d=j===0?'2026-09-19':sameDay?'2026-09-19':'2026-09-26',id='session'+j;s=C.event(s,'session-plan',{id,sets:[{id:'bench'},{id:'bench'},{id:'bench'}]},at(d),id);for(let i=0;i<(missing?2:3);i++)s=C.event(s,'set',{session:id,exercise:'bench',set:i+1,load:j?load2:145,reps:5,rir,technique:quality,target:{reps:5}},at(d),id+'-'+i)}return s}
test('Two complete steady sessions permit coach progression discussion',()=>assert.equal(C.strengthReview(sets(),'bench').ready,true));
test('Five-plus RIR is parsed without rejecting quality evidence',()=>assert.equal(C.strengthReview(sets({rir:'5+'}),'bench').ready,true));
test('Incomplete sessions do not justify progression',()=>assert.equal(C.strengthReview(sets({missing:true}),'bench').ready,false));
test('Unknown technique does not justify progression',()=>assert.equal(C.strengthReview(sets({quality:'unknown'}),'bench').ready,false));
test('Different working loads do not establish same-load repeatability',()=>assert.equal(C.strengthReview(sets({load2:150}),'bench').ready,false));
test('Two sessions on same day cannot simulate two-week progress',()=>assert.equal(C.strengthReview(sets({sameDay:true}),'bench').ready,false));
test('Low RIR does not justify progression',()=>assert.equal(C.strengthReview(sets({rir:'1'}),'bench').ready,false));
test('No baseline creates no load increase',()=>assert.equal(C.strengthReview(ready(),'bench').ready,false));
test('Future professional follow-up cannot clear present symptom',()=>{let s=C.event(ready(),'symptom',{active:true},at('2026-09-26'),'injury');s=C.event(s,'resolution',{target:'symptom-injury',professional:'Clinician',date:'2026-09-28'},at('2026-09-28'));assert.equal(C.activeSymptoms(s,sun).length,1)});
test('Hard actual outside activity influences food reference',()=>{let s=C.event(ready(),'activity',{minutes:120,rpe:8},sun);assert.deepEqual(C.nutrition(s,sun).cal,[3200,3800])});
function flat(){let s=ready();for(let i=0;i<21;i++){let d=C.add('2026-09-27',-i);s=C.event(s,'weight',{date:d,lb:160},sun,'w'+i);s=C.event(s,'intake',{date:d,calories:3200,complete:true},sun,'i'+i)}return s}
test('Stable intake trend does not automatically change calorie range',()=>{const n=C.nutrition(flat(),sun);assert.equal(n.adjust,0);assert.deepEqual(n.cal,n.baseCal);assert.equal(n.proposedFoodAddition,150);assert.equal(n.intakeMean,3200)});
test('Invalid calorie amounts cannot count as complete coverage',()=>{let s=flat();for(const e of s.events)if(e.type==='intake')e.payload.calories=null;assert.equal(C.nutrition(s,sun).proposedFoodAddition,0);assert.equal(C.nutrition(s,sun).intakeMean,null)});
test('Partial food records never establish an energy adjustment',()=>{let s=flat();for(const e of s.events)if(e.type==='intake')e.payload.complete=false;assert.equal(C.nutrition(s,sun).proposedFoodAddition,0)});
test('Actual v14.0 fixture upgrades without losing athlete fields',()=>{const old=JSON.parse(fs.readFileSync('fixtures/v14-seed.json','utf8')),n=C.migrate(old);assert.equal(n.version,C.VERSION);for(const k of Object.keys(old))if(k!=='version')assert.deepEqual(n[k],old[k])});
test('Populated v14.0 upgrade retains logs and original fact dates',()=>{let old=JSON.parse(fs.readFileSync('fixtures/v14-seed.json','utf8'));old=C.event(old,'path',{note:'Preserve this'},sun);const n=C.migrate(old);assert.deepEqual(n.events,old.events);assert.deepEqual(n.facts,old.facts);assert.deepEqual(n.archives,old.archives)});
fs.writeFileSync('audit-results.json',JSON.stringify(results,null,2));console.log(results.filter(x=>!x.pass));console.log(`${results.length} audit checks, ${results.filter(x=>!x.pass).length} failures`);process.exitCode=results.some(x=>!x.pass)?1:0;
