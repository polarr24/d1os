const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright');
const results=[],metrics={};
async function test(name,f){try{await f();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.message})}}
(async()=>{
 const html=fs.readFileSync('../index.html','utf8');
 await test('Release contains no TODO/lorem/placeholder content',()=>assert.doesNotMatch(html,/\bTODO\b|lorem ipsum|placeholder\s*=/i));
 await test('No runtime third-party scripts, frames or font imports',()=>assert.doesNotMatch(html,/<script[^>]+src=["']https?:|<iframe|@import|fonts\.googleapis|google-analytics/i));
 await test('Opponent names do not appear in decision function',()=>{const C=require('../src/core');assert.doesNotMatch(C.plan.toString(),/Durango|Palo Verde/)});
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||undefined,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
 try{
  const c=await browser.newContext({viewport:{width:402,height:874},timezoneId:'America/Los_Angeles'}),p=await c.newPage();
  await p.clock.install({time:new Date('2026-09-25T18:00:00Z')});await p.goto(pathToFileURL(path.resolve('../index.html')).href);await p.waitForFunction(()=>storage!=='checking');
  await test('Changed squat updates alternative load, without old fixed number',async()=>{await p.evaluate(()=>{S.facts.squat.value=300;page='session-preview';render()});const t=await p.locator('main').innerText();assert.match(t,/195 lb \(65% of reported 300 lb/);assert.doesNotMatch(t,/reported 295/)});
  await test('Expired coach priorities no longer become current cue',async()=>{await p.evaluate(()=>{S.facts.priorities.lastConfirmed='2026-01-01';page='today';render()});assert.match(await p.locator('main').innerText(),/Coach priorities expired/)});
  await test('Core remains usable at 402x600 keyboard-sized viewport',async()=>{await p.setViewportSize({width:402,height:600});await p.evaluate(()=>{page='checkin';render();document.querySelector('form button.primary').scrollIntoView({block:'center'})});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);const b=await p.locator('form button.primary').boundingBox(),n=await p.locator('nav').boundingBox();assert.ok(b.y+b.height<=n.y)});
  await p.setViewportSize({width:402,height:874});await p.evaluate(()=>{page='today';render()});
  const client=await c.newCDPSession(p);await client.send('Performance.enable');
  const read=async()=>Object.fromEntries((await client.send('Performance.getMetrics')).metrics.map(x=>[x.name,x.value]));
  await new Promise(r=>setTimeout(r,1700));const before=await read();await new Promise(r=>setTimeout(r,2000));const after=await read();
  metrics.idleWindowSeconds=2;metrics.idleTaskMilliseconds=1000*(after.TaskDuration-before.TaskDuration);metrics.heapUsedBytes=after.JSHeapUsedSize;
  await test('Idle main-thread work under 250ms in measured 2s window',()=>assert.ok(metrics.idleTaskMilliseconds<250));
  metrics.renderMilliseconds=await p.evaluate(()=>{const out=[];for(const dest of ['today','field','train','lab','path']){const t=performance.now();page=dest;render();out.push({page:dest,ms:performance.now()-t})}return out});
  await test('Five measured synchronous screen renders each under 100ms',()=>assert.ok(metrics.renderMilliseconds.every(x=>x.ms<100)));
  metrics.browser=await browser.version();await c.close();
 }finally{await browser.close()}
 fs.writeFileSync('release-results.json',JSON.stringify({results,metrics},null,2));console.log(results.filter(x=>!x.pass));console.log(`${results.length} release checks, ${results.filter(x=>!x.pass).length} failures`);process.exitCode=results.some(x=>!x.pass)?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
